# coverflow-javascript



• Mon fichier CSS
• Mon fichier JavaScript
• Mon fichier HTML


• Mon fichier CSS

Commençant par mon fichier CSS, Je dois utiliser l’effect ‘coverflow' en indiquant sa rotation, sa
profondeur et à quel point ils sera prolongé.
coverflow : { rotate: 50, stretch: 0, depth: 100, modifier: 1).

Je crée le background de mon site, je donne mes instructions, la taille en largeur et en
longueur, je passe au CSS transforme + le 3D, je ferai 3 style (1er horizontal, 2eme
verticale qui auront l’option transform-style: preserve-3d) et le 3eme qui sera horizontal
normale avec l’effet de glissement bien sur et un zoom automatique quand on le mouse
s’indique sur une image.


• Mon fichier JavaScript

Je met des petites flèches à droite et à gauche pour choisir la direction des mes images.

Je pense avoir besoin d’une seule classe pour le coverflow qui contiendra un tableau
d’image.

J’ai mon image principale et j’ai des images derrières.

Je crée ma fonction trigonométrique (sinus, cosinus et tangente).



• Mon fichier HTML

Un fichier normal ou je métrerai les appels aux fichiers / dossier etc..
